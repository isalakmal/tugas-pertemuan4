<?php require('header.php'); ?>
<div class="container">
    <h2>About</h2>
    <div class="box">
        <p>Sekian Terimakasih.</p>
    </div>
</div>
<?php require('footer.php'); ?>
