<?php require('header.php'); ?>
<div class="container">
    <h2>Kontak</h2>
    <div class="box">
        <p>Nama : Faisal akmal fidaus</p>
        <p>Nim : 312110160</p>
        <p>Kelas : TI.21.A.1</p>
        <p>Matkul : Pemograman Web 2</p>
        <p>Email : kepoya@gmail.com</p>
        <p>No. Telp : 085746****</p>
    </div>
</div>
<?php require('footer.php'); ?>
