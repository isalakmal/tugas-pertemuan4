<head><link href="style.css" rel="stylesheet" type="text/css"></head>
<footer>
    <p>&copy; 2021, Informatika, Universitas Pelita Bangsa</p>
</footer>
</div>
</body>

</html>